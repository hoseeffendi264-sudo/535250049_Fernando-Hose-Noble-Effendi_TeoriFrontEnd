import Image from "next/image";

export default function Home() {
return (
<>
<header className="header">
  <div className="container header-container">
    <h1 className="logo">Kopi Nusantara</h1>
    <nav className="nav">
      <a href="#beranda">Beranda</a>
      <a href="#menu">Menu</a>
      <a href="#tentang">Tentang</a>
      <a href="#kontak">Kontak</a>
    </nav>
  </div>
</header>

<section className="hero" id="beranda">
  <div className="hero-overlay"></div>
  <div className="container hero-content">
    <h2>Cita Rasa Nusantara</h2>
    <p>
      Nikmati kopi terbaik dari berbagai penjuru Indonesia.
    </p>
    <a href="#menu" className="btn">
      Lihat Menu Kami
    </a>
  </div>
</section>

<section className="menu-section" id="menu">
  <div className="container">
    <h2 className="section-title">Menu Kopi</h2>
    <p className="section-subtitle">
      Pilihan kopi dan minuman terbaik dari seluruh Nusantara
    </p>

    <div className="menu-grid">
      <div className="card">
        <Image
          src="/img/kopi1.jpg"
          alt="Ketoprak Original dengan kerupuk"
          width={400}
          height={220}
        />
        <div className="card-body">
          <h3>Kopi Gayo</h3>
          <p>
            Kopi arabika premium dari dataran tinggi Gayo, Aceh. Rasa full body dengan aroma earthy dan sedikit fruity.
          </p>
          <span className="price">Rp 25.000</span>
        </div>
      </div>

      <div className="card card-jumbo">
        <Image
          src="/img/kopi2.jpg"
          alt="Ketoprak Jumbo porsi besar"
          width={400}
          height={220}
        />
        <div className="card-body">
          <h3>Kopi Toraja</h3>
          <p>
            Kopi arabika khas Sulawesi Selatan dengan cita rasa herbal, spicy, dan dark chocolate.
          </p>
          <span className="price">Rp 28.000</span>
        </div>
      </div>

      <div className="card">
        <Image
          src="/img/kopi3.jpg"
          alt="Ketoprak Komplit dengan tahu dan tauge"
          width={400}
          height={220}
        />
        <div className="card-body">
          <h3>Kopi Kintamani</h3>
          <p>
            Kopi arabika dari Bali dengan karakter citrusy, clean, dan aroma jeruk yang segar.
          </p>
          <span className="price">Rp 27.000</span>
        </div>
      </div>

      <div className="card">
        <Image
          src="/img/kopi4.jpg"
          alt="Ketoprak Telur dengan timun"
          width={400}
          height={220}
        />
        <div className="card-body">
          <h3>Es Kopi Susu Nusantara</h3>
          <p>
            Signature drink kami! Perpaduan espresso, susu segar, dan gula aren asli.
          </p>
          <span className="price">Rp 22.000</span>
        </div>
      </div>

      <div className="card">
        <Image
          src="/img/kopi5.jpg"
          alt="Ketoprak Komplit dengan tahu dan tauge"
          width={400}
          height={220}
        />
        <div className="card-body">
          <h3>Kopi Flores Bajawa</h3>
          <p>
            Kopi arabika dari NTT dengan rasa nutty, chocolatey, dan body yang medium.
          </p>
          <span className="price">Rp 30.000</span>
        </div>
      </div>
    </div>
  </div>
</section>

<section className="about-section" id="tentang">
  <div className="about-image">
    <img
      src="/img/tentang.jpg"
      alt="Biji kopi Nusantara dengan secangkir kopi"
    />
  </div>

  <div className="about-content">
    <h1>Tentang Kopi Nusantara</h1>

    <div className="title-underline"></div>

    <div className="about-description">
      <p>
        <strong>Kopi Nusantara</strong> didirikan dengan semangat
        untuk memperkenalkan kekayaan kopi Indonesia kepada dunia.
        Kami bekerja langsung dengan petani kopi lokal dari Aceh
        hingga Papua untuk menghadirkan biji kopi berkualitas
        terbaik.
      </p>

      <p>
        Setiap cangkir kopi yang kami sajikan adalah hasil dari
        proses roasting yang cermat dan penyeduhan yang penuh
        perhatian, agar cita rasa asli dari setiap daerah asal
        kopi dapat dinikmati sepenuhnya.
      </p>
    </div>

    <div className="about-stats">
      <div className="stat-card">
        <h2>5+</h2>
        <p>Daerah Asal</p>
      </div>

      <div className="stat-card">
        <h2>10K+</h2>
        <p>Cangkir Terjual</p>
      </div>

      <div className="stat-card">
        <h2>4.8</h2>
        <p>Rating</p>
      </div>
    </div>
  </div>
</section>

<footer className="footer" id="kontak">
  <div className="footer-container">

    <div className="footer-col">
      <h3 className="footer-title">
        Kopi Nusantara
      </h3>
      <p className="footer-desc">
        Menghadirkan cita rasa kopi terbaik dari berbagai penjuru Nusantara ke dalam setiap cangkir yang kami sajikan.
      </p>
    </div>

    <div className="footer-col center-col">
      <h3 className="footer-title">Jam Operasional</h3>
      <p>Senin - Jumat: 07.00 - 22.00</p>
      <p>Sabtu - Minggu: 08.00 - 23.00</p>
    </div>

    <div className="footer-col right-col">
      <h3 className="footer-title">Hubungi Kami</h3>
      
      <ul className="contact-list">
        <li>
          <span>Jl. Kopi No. 17, Jakarta Selatan</span>
        </li>
        <li>
          <span>0812-3456-7890</span>
        </li>
        <li>
          <span>halo@kopinusantara.id</span>
        </li>
      </ul>
    </div>

  </div>

  <div className="footer-divider"></div>
  <div className="footer-bottom">
    <p>&copy; 2026 Kopi Nusantara. All rights reserved.</p>
  </div>
</footer>
</>
);
}